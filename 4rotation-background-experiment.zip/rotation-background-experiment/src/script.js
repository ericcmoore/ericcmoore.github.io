// NOTE: Javascript is in the head (found in the HTML section here)
// For more check out zachsaucier.com