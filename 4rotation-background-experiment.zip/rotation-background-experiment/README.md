# Rotation & background experiment

A Pen created on CodePen.io. Original URL: [https://codepen.io/ZachSaucier/pen/xxxyYj](https://codepen.io/ZachSaucier/pen/xxxyYj).

Move your mouse around, see the result. No SVG/canvas/anything else! I really like the effect

More rotational objects can be added easily, just add the appropriate HTML structure (including the necessary classes)

This could also be combined with a CSS-only square container and made responsive very easily. For an example of the technique, check here http://codepen.io/Zeaklous/pen/ImGaH

Inspired by http://25.media.tumblr.com/918162ed1f057a800b05dca55cf30764/tumblrmuihqpB1Kx1rf78nfo1r1_400.gif

Vanilla JS performance so nice. It'd be interesting to see this with more picture sections (the math would have to be changed)

All gifs taken from http://seamlessgifs.tumblr.com/